import { Component, OnInit, OnDestroy } from '@angular/core';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { Subscription } from 'rxjs';

interface Player {
  name: string;
  gender: 'male' | 'female';
}

interface BodyPart {
  name: { es: string; en: string };
  image: string;
  isIntimate: boolean;
}

@Component({
  selector: 'app-kiss-roulette',
  templateUrl: './kiss-roulette.component.html',
  styleUrls: ['./kiss-roulette.component.css']
})
export class KissRouletteComponent implements OnInit, OnDestroy {
  // Configuración
  players: Player[] = [];
  includeIntimateParts = false;
  kissDuration = 30;
  showInstructions = true;
  
  // Estados del juego
  currentPhase: 'setup' | 'spinning' | 'result' | 'kissCountdown' = 'setup';
  currentBodyPart = '';
  targetPlayer = '';
  currentPlayerIndex = 0;
  currentPlayerName = '';
  
  // Ruletas
  spinningBody = false;
  spinningPlayer = false;
  
  // Temporizador del beso
  countdownTime = 0;
  countdownInterval: any;
  
  // Traducciones
  labels: any = {};
  private langSub?: Subscription;

  // Listas
  bodyParts: BodyPart[] = [
    { name: { es: 'MANO', en: 'HAND' }, image: '🖐️', isIntimate: false },
    { name: { es: 'MEJILLA', en: 'CHEEK' }, image: '😊', isIntimate: false },
    { name: { es: 'FRENTE', en: 'FOREHEAD' }, image: '🤔', isIntimate: false },
    { name: { es: 'HOMBRO', en: 'SHOULDER' }, image: '💪', isIntimate: false },
    { name: { es: 'ESPALDA', en: 'BACK' }, image: '🔙', isIntimate: false },
    { name: { es: 'CUELLO', en: 'NECK' }, image: '👔', isIntimate: false },
    { name: { es: 'PIE', en: 'FOOT' }, image: '👣', isIntimate: false },
    { name: { es: 'OMBLIGO', en: 'NAVEL' }, image: '🌀', isIntimate: true },
    { name: { es: 'MUSLO', en: 'THIGH' }, image: '🦵', isIntimate: true },
    { name: { es: 'PECHO', en: 'CHEST' }, image: '❤️', isIntimate: true },
    { name: { es: 'GLÚTEOS', en: 'BUTTOCKS' }, image: '🔴', isIntimate: true },
    { name: { es: 'PARTE ÍNTIMA', en: 'INTIMATE PART' }, image: '⚡', isIntimate: true }
  ];

  playfulMessages: { [key: string]: string[] } = {
    es: [
      "¡Que comience el juego de los besos! 💋",
      "Hora de demostrar tu pasión... 😏",
      "¿Listo para este momento íntimo? 🌶️"
    ],
    en: [
      "Let the kissing game begin! 💋",
      "Time to show your passion... 😏",
      "Ready for this intimate moment? 🌶️"
    ]
  };

  constructor(private translate: TranslateService) {}

  ngOnInit() {
    this.loadTranslations();
    this.langSub = this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
      this.loadTranslations();
    });
  }

  ngOnDestroy() {
    this.clearCountdown();
    this.langSub?.unsubscribe();
  }

  private loadTranslations() {
    this.translate.get('KISS_ROULETTE').subscribe((res) => {
      this.labels = res;
    });
  }

  getRandomPlayfulMessage(): string {
    const currentLang = this.translate.currentLang || 'es';
    const messages = this.playfulMessages[currentLang] || this.playfulMessages['es'];
    return messages[Math.floor(Math.random() * messages.length)];
  }

  getBodyPartName(bodyPart: BodyPart): string {
    const currentLang = this.translate.currentLang || 'es';
    return bodyPart.name[currentLang as 'es' | 'en'] || bodyPart.name.es;
  }

  // Agregar jugador
  addPlayer(name: string, gender: string) {
    if (name.trim() && this.players.length < 8) {
      const validGender = gender === 'male' || gender === 'female' ? gender : 'female';
      this.players.push({ 
        name: name.trim(), 
        gender: validGender 
      });
    }
  }

  // Remover jugador
  removePlayer(index: number) {
    this.players.splice(index, 1);
    if (this.currentPlayerIndex >= this.players.length) {
      this.currentPlayerIndex = 0;
    }
  }

  // Actualizar duración del beso
  updateKissDuration(duration: number) {
    this.kissDuration = duration;
  }

  // Cerrar instrucciones
  closeInstructions() {
    this.showInstructions = false;
  }

  // Mostrar instrucciones nuevamente
  showInstructionsAgain() {
    this.showInstructions = true;
  }

  // Iniciar juego - CORREGIDO
  startGame() {
    if (this.players.length >= 2) {
      this.currentPlayerIndex = 0;
      this.currentPlayerName = this.players[this.currentPlayerIndex].name;
      this.currentPhase = 'spinning';
      // Resetear resultados anteriores
      this.currentBodyPart = '';
      this.targetPlayer = '';
      this.spinningBody = false;
      this.spinningPlayer = false;
    }
  }

  // Girar ruletas - CORREGIDO
  spinRoulettes() {
    if (this.spinningBody || this.spinningPlayer) return;
    
    this.spinningBody = true;
    this.spinningPlayer = true;
    this.currentBodyPart = '';
    this.targetPlayer = '';
    
    this.spinBodyPart();
  }

  // Girar ruleta de partes del cuerpo - CORREGIDO
  spinBodyPart() {
    const availableParts = this.includeIntimateParts 
      ? this.bodyParts 
      : this.bodyParts.filter(part => !part.isIntimate);
    
    let spins = 0;
    const maxSpins = 15;
    
    const bodyInterval = setInterval(() => {
      const randomIndex = Math.floor(Math.random() * availableParts.length);
      this.currentBodyPart = this.getBodyPartName(availableParts[randomIndex]);
      spins++;
      
      if (spins >= maxSpins) {
        clearInterval(bodyInterval);
        this.spinningBody = false;
        const finalIndex = Math.floor(Math.random() * availableParts.length);
        this.currentBodyPart = this.getBodyPartName(availableParts[finalIndex]);
        // Ahora girar la ruleta de jugadores
        this.spinPlayer();
      }
    }, 150);
  }

  // Girar ruleta de jugadores - CORREGIDO
  spinPlayer() {
    let spins = 0;
    const maxSpins = 15;
    
    const playerInterval = setInterval(() => {
      let randomIndex;
      do {
        randomIndex = Math.floor(Math.random() * this.players.length);
      } while (randomIndex === this.currentPlayerIndex && this.players.length > 1);
      
      this.targetPlayer = this.players[randomIndex].name;
      spins++;
      
      if (spins >= maxSpins) {
        clearInterval(playerInterval);
        this.spinningPlayer = false;
        
        let finalIndex;
        do {
          finalIndex = Math.floor(Math.random() * this.players.length);
        } while (finalIndex === this.currentPlayerIndex && this.players.length > 1);
        
        this.targetPlayer = this.players[finalIndex].name;
        this.currentPhase = 'result';
      }
    }, 150);
  }

  // Iniciar countdown del beso
  startKissCountdown() {
    this.countdownTime = this.kissDuration;
    this.currentPhase = 'kissCountdown';
    
    this.countdownInterval = setInterval(() => {
      this.countdownTime--;
      
      if (this.countdownTime <= 0) {
        this.clearCountdown();
        this.currentPhase = 'result';
      }
    }, 1000);
  }

  // Limpiar countdown
  clearCountdown() {
    if (this.countdownInterval) {
      clearInterval(this.countdownInterval);
      this.countdownInterval = null;
    }
  }

  // Formatear tiempo (MM:SS)
  formatTime(seconds: number): string {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }

  // Siguiente turno - CORREGIDO
  nextTurn() {
    this.clearCountdown();
    this.currentPlayerIndex = (this.currentPlayerIndex + 1) % this.players.length;
    this.currentPlayerName = this.players[this.currentPlayerIndex].name;
    this.currentBodyPart = '';
    this.targetPlayer = '';
    this.spinningBody = false;
    this.spinningPlayer = false;
    this.currentPhase = 'spinning';
  }

  // Reiniciar juego completo
  resetGame() {
    this.clearCountdown();
    this.currentPhase = 'setup';
    this.currentBodyPart = '';
    this.targetPlayer = '';
    this.currentPlayerIndex = 0;
    this.currentPlayerName = '';
    this.spinningBody = false;
    this.spinningPlayer = false;
    this.countdownTime = 0;
  }

  // Obtener imagen de la parte del cuerpo
  getBodyPartImage(partName: string): string {
    const part = this.bodyParts.find(p => 
      p.name.es === partName || p.name.en === partName
    );
    return part ? part.image : '💖';
  }

  // Verificar si puede iniciar el juego
  canStartGame(): boolean {
    return this.players.length >= 2;
  }

  // Verificar si puede girar
  canSpin(): boolean {
    return this.currentPhase === 'spinning' && !this.spinningBody && !this.spinningPlayer;
  }
}