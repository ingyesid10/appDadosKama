import { Component, OnInit, OnDestroy } from '@angular/core';
import { CombinacionesService } from '../../../core/services/combinaciones.service';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-dice',
  templateUrl: './dice.component.html',
  styleUrls: ['./dice.component.css']
})
export class DiceComponent implements OnInit, OnDestroy {
  leftDisplay: number | string = '-';
  rightDisplay: number | string = '-';
  showResult = false;
  resultImageSrc = '/assets/img/default.png';
  resultName = '';
  resultDesc = '';
  resultAdvantages: string[] = [];
  resultDisadvantages: string[] = [];
  resultFunFact: string = '';
  countdownRemaining = 60;
  countdownInterval: any = null;
  modalSeconds = 60;
  spinning = false;
  combos: any = {};
  selectedCombination: any = null;
  langSubscription!: Subscription;

  constructor(
    private combinacionesService: CombinacionesService,
    private translate: TranslateService
  ) {}

  ngOnInit() {
    this.loadCombinations();

    // Detectar cambio de idioma en tiempo real
    this.langSubscription = this.translate.onLangChange.subscribe(() => {
      this.loadCombinations();
      // Actualizar resultado visible si ya hay uno
      if (this.leftDisplay !== '-' && this.rightDisplay !== '-') {
        this.finalizeResult(Number(this.leftDisplay), Number(this.rightDisplay));
      }
    });
  }

  ngOnDestroy() {
    if (this.langSubscription) this.langSubscription.unsubscribe();
  }

  /** Carga las combinaciones según idioma */
  loadCombinations() {
    const lang = this.translate.currentLang || 'es';
    this.combinacionesService.getCombinaciones(lang as 'es' | 'en').subscribe(data => {
      this.combos = data || {};
      console.log('✅ Combinaciones cargadas:', lang, this.combos);
    });
  }

  /** Inicia el giro de los dados */
  startSpin() {
    if (this.spinning) return;
    this.showResult = false;
    this.spinning = true;

    const spinDuration = 1200 + Math.random() * 600;
    const spinInterval = setInterval(() => {
      this.leftDisplay = this.randDieValue();
      this.rightDisplay = this.randDieValue();
    }, 80);

    setTimeout(() => {
      clearInterval(spinInterval);
      const left = this.randDieValue();
      const right = this.randDieValue();
      this.leftDisplay = left;
      this.rightDisplay = right;
      this.spinning = false;
      this.finalizeResult(left, right);
    }, spinDuration);
  }

  randDieValue() {
    return Math.floor(Math.random() * 6) + 1;
  }

  /** Finaliza el resultado de los dados y carga la combinación */
  finalizeResult(left: number, right: number) {
    this.showResult = true;
    const key = `${left}-${right}`;
    const lang = this.translate.currentLang || 'es';
    this.selectedCombination = this.combos[key] || this.combos[`${right}-${left}`] || null;

    if (this.selectedCombination) {
      this.updateTexts(lang);
    } else {
      this.resultName = `Result ${left}-${right}`;
      this.resultDesc = `No description available.`;
      this.resultAdvantages = [];
      this.resultDisadvantages = [];
      this.resultFunFact = '';
      this.resultImageSrc = '/assets/img/default.png';
    }
  }

  /** Actualiza los textos y la imagen según el idioma */
  updateTexts(lang?: string) {
    if (!this.selectedCombination) return;
    lang = lang || this.translate.currentLang || 'es';

    if (lang === 'es') {
      this.resultName = this.selectedCombination.nombre;
      this.resultDesc = this.selectedCombination.descripcion;
      this.resultAdvantages = this.selectedCombination.ventajas || [];
      this.resultDisadvantages = this.selectedCombination.desventajas || [];
      this.resultFunFact = this.selectedCombination.dato_curioso || '';
      this.resultImageSrc = this.selectedCombination.imagen?.replace(/^\.?\/?assets\//, '/assets/') || '/assets/img/default.png';
    } else {
      this.resultName = this.selectedCombination.name;
      this.resultDesc = this.selectedCombination.description;
      this.resultAdvantages = this.selectedCombination.advantages || [];
      this.resultDisadvantages = this.selectedCombination.disadvantages || [];
      this.resultFunFact = this.selectedCombination.fun_fact || '';
      this.resultImageSrc = this.selectedCombination.image?.replace(/^\.?\/?assets\//, '/assets/') || '/assets/img/default.png';
    }
  }

  startCountdown() {
    if (this.countdownInterval) clearInterval(this.countdownInterval);
    this.countdownRemaining = Math.max(1, Math.floor(this.modalSeconds));
    this.countdownInterval = setInterval(() => {
      this.countdownRemaining--;
      if (this.countdownRemaining <= 0) {
        clearInterval(this.countdownInterval);
        this.countdownInterval = null;
        alert(this.translate.instant('dice.timeUp'));
      }
    }, 1000);
  }

  formatTimer(sec: number) {
    const s = Math.max(0, Math.floor(sec || 0));
    const mm = String(Math.floor(s / 60)).padStart(2, '0');
    const ss = String(s % 60).padStart(2, '0');
    return `${mm}:${ss}`;
  }

  resetCountdown() {
    if (this.countdownInterval) clearInterval(this.countdownInterval);
    this.countdownRemaining = this.modalSeconds;
  }
}
