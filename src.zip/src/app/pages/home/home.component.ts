import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, NavigationEnd, Event as RouterEvent } from '@angular/router';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { GameModalService } from 'src/app/core/services/game-modal.service';
import { TranslateService } from '@ngx-translate/core';

interface GameItem {
  name: string;
  icon: string;
  id: string;
  categories: string[];
  translatedName?: string;
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomePage implements OnInit, OnDestroy {

  showSelector = true;
  showGames = false;
  introText = '';
  messageNext = '';
  filteredGames: any[] = [];
  private routerSub?: Subscription;

  // 👇 usamos claves de traducción, no texto directo
  allGames : GameItem[] =[
    { name: 'GAMES.DICE_KAMASUTRA', icon: '🎲', id: 'juego-de-dados', categories: ['pareja'] },
    { name: 'GAMES.CHALLENGE_ROULETTE', icon: '🎰', id: 'ruleta-de-retos', categories: ['fiesta', 'pareja'] },
    { name: 'GAMES.TRUTH_OR_DARE_PENALTY', icon: '🤫', id: 'juego-de-retos', categories: ['fiesta', 'pareja'] },
    { name: 'GAMES.TRUTH_OR_DARE_SIMPLE', icon: '🫣', id: 'juego-de-verdad', categories: ['fiesta', 'pareja'] },
    { name: 'GAMES.KISS_ROULETTE', icon: '💋', id: 'juego-de-besos', categories: ['fiesta', 'pareja'] },
    { name: 'GAMES.DICE_ORAL', icon: '🥵', id: 'juego-de-parejas-oral', categories: ['na'] },
    { name: 'GAMES.SPIN_BEER', icon: '🍺', id: 'ruleta-de-tragos', categories: ['fiesta'] },
    { name: 'GAMES.COUPLE_CHALLENGE', icon: '❤️', id: 'desafio-de-parejas', categories: ['na'] }
  ];

  constructor(
    private gameModalService: GameModalService,
    private router: Router,
    private translate: TranslateService
  ) {}

  ngOnInit(): void {
    this.resetHome();

    // 🌀 Re-traduce todo si cambia el idioma
    this.translate.onLangChange.subscribe(() => {
      this.translateGameNames();
      // this.resetHome();
       this.updateTexts();
    });

    // 🧭 Detecta si vuelve a /home
    this.routerSub = this.router.events
      .pipe(filter((event: RouterEvent): event is NavigationEnd => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        if (event.urlAfterRedirects === '/home' || event.url === '/home') {
          this.resetHome();
        }
      });
  }

  ngOnDestroy(): void {
    this.routerSub?.unsubscribe();
  }

  private updateTexts(): void {
  // Actualiza texto de introducción o mensaje siguiente según la vista actual
  if (this.showSelector) {
    this.translate.get('HOME.INTRO').subscribe(text => {
      this.introText = text;
    });
  } else {
    this.setRandomMessage();
  }
}

  // 🧠 Restaura estado y textos
  resetHome(): void {
    this.showSelector = true;
    this.showGames = false;
    this.filteredGames = [];
    this.translateGameNames();
    this.setRandomMessage();

    this.translate.get('HOME.INTRO').subscribe(text => {
      this.introText = text;
    });
  }

  // 🈹 Traduce los nombres de los juegos
  private translateGameNames(): void {
    this.allGames.forEach(game => {
      game.translatedName = this.translate.instant(game.name);
    });
  }

  // 🌀 Mensaje aleatorio traducido
  private setRandomMessage(): void {
    this.translate.get('HOME.RANDOM_MESSAGES').subscribe((messages: string[]) => {
      const index = Math.floor(Math.random() * messages.length);
      this.messageNext = messages[index];
    });
  }

  selectCategory(category: string): void {
    this.showSelector = false;
    this.showGames = true;
    this.filteredGames = this.allGames.filter(game => game.categories.includes(category));
  }

  open(gameId: string): void {
    this.gameModalService.open(gameId);
  }

  goBack(): void {
    this.resetHome();
  }
}
