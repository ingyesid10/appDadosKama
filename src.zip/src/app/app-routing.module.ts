import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

// 👇 Importa tus componentes principales
import { HomePage } from './pages/home/home.component';
// import { ExplorarComponent } from './pages/explorar/explorar.component';
// import { FavoritosComponent } from './pages/favoritos/favoritos.component';
// import { ConfigComponent } from './pages/config/config.component';

const routes: Routes = [
    // 👇 Esta línea hace que por defecto se abra el Home
    { path: '', redirectTo: 'home', pathMatch: 'full' },

    // 👇 Rutas principales de tu app
    { path: 'home', component: HomePage },
    //   { path: 'explorar', component: ExplorarComponent },
    //   { path: 'favoritos', component: FavoritosComponent },
    //   { path: 'config', component: ConfigComponent },

    // 👇 Cualquier ruta desconocida redirige también al Home
    { path: '**', redirectTo: 'home' }
];

@NgModule({
    imports: [RouterModule.forRoot(routes, {
        onSameUrlNavigation: 'reload', // ✅ permite recargar el componente al navegar al mismo path
        scrollPositionRestoration: 'enabled' // opcional: restaura el scroll al inicio
    })],
    exports: [RouterModule]
})
export class AppRoutingModule { }
