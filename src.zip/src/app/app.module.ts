import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { ModalComponent } from './components/modal/modal.component';

//miniGames
import { DiceComponent } from './components/mini-games/dice/dice.component';
import { RouletteComponent } from './components/mini-games/roulette/roulette.component';
import { DesprendeteComponent } from './components/mini-games/desprendete/desprendete.component';
import { SpinBeerComponent } from './components/mini-games/spin-beer/spin-beer.component';
import { TruthOrDareComponent } from './components/mini-games/truth-or-dare/truth-or-dare.component';
import { KissRouletteComponent } from './components/mini-games/kiss-roulette/kiss-roulette.component';

//cookie
import { CookieConsentComponent } from './components/cookie-consent/cookie-consent.component';
import { HomePage } from './pages/home/home.component';
import { CommonModule } from '@angular/common';

// ✅ Configuración clásica y estable
export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

@NgModule({
  declarations: [
    AppComponent,
    SidebarComponent,
    ModalComponent,
    DiceComponent,
    RouletteComponent,
    HomePage,
    DesprendeteComponent,
    CookieConsentComponent,
    SpinBeerComponent,
    TruthOrDareComponent,
    KissRouletteComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    CommonModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      },
      defaultLanguage: 'es'
    })
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
