export const environment = {
  production: true,
  jsonDataES: 'assets/data/combinacionesES.json',
  jsonDataEN: '/assets/data/combinacionesEN.json',
  jsonDataRuletaES: 'assets/data/ruleta-es.json',
  jsonDataRuletaEN: 'assets/data/ruleta-en.json',
  jsonDataRuletaPrendaES: 'assets/data/verdad-es.json',
  jsonDataRuletaPrendaEN: 'assets/data/verdad-en.json',
  dataUrlVerdadReto: "assets/data/dev/verdad-es.json",
  idiomaPorDefecto: 'es' as 'es' | 'en',
  dadosImg: "assets/img/dados/",
  API_URL: 'http://localhost:4200/assets/json/',  // ruta local
  IMAGES_PATH: 'assets/img/',
  ERROR_GENERIC_HOME: 'Ocurrió un error al cargar los datos. Intenta de nuevo.'
};