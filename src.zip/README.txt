Arcade Pícara - Angular (final scaffold)

Estructura:
- app/
  - core/services/combinaciones.service.ts  (servicio para leer assets/data/combinaciones.json)
  - pages/home/                             (home page)
  - components/modal/
  - components/mini-games/dice
  - components/mini-games/roulette

Instrucciones:
1. Extrae este ZIP.
2. En la carpeta raíz, ejecuta:
   npm install
   npm install -g @angular/cli   (si no tienes ng)
3. ng serve

Notas:
- Reemplaza src/assets/data/combinaciones.json con tu archivo completo (mantén la clave "imagen").
- Asegúrate de colocar las imágenes en src/assets/img/nivel1/ según las rutas del JSON.
- El proyecto es un scaffold; si quieres que lo convierta en un proyecto con Angular Router y módulos separados, dime y lo hago.

